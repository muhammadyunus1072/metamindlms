<a
    class="avatar avatar-sm mr-12pt">
    <span class="avatar-title rounded-circle">
        <span class="material-icons">person</span>
    </span>
</a>