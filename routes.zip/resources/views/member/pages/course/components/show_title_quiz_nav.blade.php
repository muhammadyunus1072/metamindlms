<div class="navbar navbar-expand-sm navbar-light bg-white border-bottom-2 navbar-list p-0 m-0 align-items-center">
    <div class="container page__container">
        <ul class="nav navbar-nav flex align-items-sm-center">
            <li class="nav-item navbar-list__item">
                <div class="media align-items-center">
                    <div class="media-body">
                        <p class="lead text-70 ">{{ $results_data->description }}</p>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</div>
