<?php

namespace App\Helpers;

class FileHelper
{
    const WEBSITE_USER = 'http://localhost:8000';

    const IMAGE_PATH = '/attachments/images/';
    const FILE_PATH = '/attachments/files/';

    // SAVE FILE
    const COURSE_SAVE_LOCATION = self::FILE_PATH . 'course/';
    const OFFLINE_COURSE_SAVE_LOCATION = self::FILE_PATH . 'offline_course/';

    // READ FILE
    const COURSE_READ_LOCATION = self::WEBSITE_USER . self::FILE_PATH . 'course/';
    const OFFLINE_COURSE_READ_LOCATION = self::WEBSITE_USER . self::FILE_PATH . 'offline_course/';
}
